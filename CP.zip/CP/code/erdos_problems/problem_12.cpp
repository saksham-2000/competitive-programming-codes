#include <bits/stdc++.h>
using namespace std;


int main() 
{ 
   typedef long long unsigned int ll;
   ll t=100001,j=0, prime[10]={0};
   while(t-->0)
   {
    bool isPrime=true;
    ll n;
    cin>>n;
    for(int i=2;i*i<=n;i++)
    {
if(n%i==0)
{ 
    isPrime=false;
    break;
}


    }
    if(isPrime)
{
    
    prime[j]=n;
    j++;
    
}

   }

   cout<<"\n";

   cout<<prime[1]<<"\n"<<prime[0]<<"\n";

   return 0;

}
    // in file 12.txt ,luckily there are only 2 prime numbers. :)