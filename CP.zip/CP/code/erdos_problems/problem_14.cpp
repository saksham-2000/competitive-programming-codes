#include <bits/stdc++.h>
using namespace std;


int main() {
    typedef long long int ll;
    ll fibonacci[40];
    fibonacci[0]=0,fibonacci[1]=1;
    for(int i=2;i<40;i++)
    {
        fibonacci[i]=fibonacci[i-1]+fibonacci[i-2];
    }
   

ll t=60027,count=0;
while(t-->0)
{
ll n;
cin>>n;
for(int i=0;i<40;i++)
{
  if(n==fibonacci[i])
{
    count++;
    break;
}
if(fibonacci[i]>n)
{
    break;
}

}


}

cout<<count<<"\n";

	return 0;
}