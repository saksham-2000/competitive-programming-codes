#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
ll power(ll a,ll n,ll m)
{ 
    
    if(n==0)
        return 1;
    else if(n==1)
        return a%m;
    else
    {
        ll res=power(a,n/2,m);
        if(n%2==0)
            return ((res%m)*(res%m))%m;
    
    else
        return ((res%m)*(res%m)*(a%m))%m;
    }
}

int main()
{
  ll i,j,ans=7,temp=0;
  ll arr[16]={0};
  const ll m = 12345678;
  for(j=0;j<=15;j++)
  {

  for(i=0;i<=9;i++)
  {
    
    temp=(ll)(pow(10,j)+0.5);
    temp*=i;
    arr[j]+=power(10,temp,m);
  }
  arr[j]=arr[j]%m;
  }

for(j=0;j<16;j++)
{
  ans=(ans*arr[j])%m;
}

cout<<ans<<endl;

    
 
return 0;

}
     


    

    


    

    

    

    


    

    
    

    


    

    


    

    


    

    
    

    


    

    