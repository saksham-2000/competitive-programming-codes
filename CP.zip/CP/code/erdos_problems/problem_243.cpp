#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
ll power(ll a,ll n,ll m)
{ 
    
    if(n==0)
        return 1;
    else if(n==1)
        return a%m;
    else
    {
        ll res=power(a,n/2,m);
        if(n%2==0)
            return ((res%m)*(res%m))%m;
    
    else
        return ((res%m)*(res%m)*(a%m))%m;
    }
}


ll ans(ll n,ll m)
{
  if(n==2)return 1;
  else return (2*ans(n-1,m))%m +power(2,n-2,m);
}
int main()
{

ll j;
ll m=1000000007;

               
cout<<ans(12345,m)<<endl;           
  
return 0;

}
     


    

    


    

    

    

    


    

    
    

    


    

    


    

    


    

    
    

    


    

    