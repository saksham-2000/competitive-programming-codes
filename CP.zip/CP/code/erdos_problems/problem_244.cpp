#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
int main()
{
  ll n=1000000007,j;
 /* for(ll i=n-1;i>0;i--)
  {
    ll flag=0;
    for(j=2;j*j<=i;j++)
    {
      if(i%j==0)
        {
          
          flag=1;
          break;
        }
    }
    if(flag==0)
      {
        cout<<i<<endl;
        break;
      }
    
  }*/

  cout<<(n-2)*(n+1)/2;         // observation se yeh formula ban gya. :)
                          
  
return 0;

}
     


    

    


    

    

    

    


    

    
    

    


    

    


    

    


    

    
    

    


    

    