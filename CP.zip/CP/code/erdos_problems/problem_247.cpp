#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;
ll fac(int n)
{                               
  if(n==1)return 1;                                  // second solution (recursive solution) : (F)n= n*(F)n-1 + (nc2)*((n-1)!)
  
  else return n*fac(n-1);
}

ll ways(int n)
{
  if(n==2)return 1;
  else return n*ways(n-1)+ fac(n)*(n-1)/2;
}

int main()
{
 /*ll i,ans=1;
 for(i=15;i>=1;i--)
 {
  ans*=i;
 }
 ans*=15*7;                             //   first solution : (n)!*(nc2)/2 = no. of possible inversions for order n over all possible permutations.
 ans/=2;
 cout<<ans<<endl;
  */
  cout<<ways(15)<<endl;
return 0;

}
     


    

    


    

    

    

    


    

    
    

    


    

    


    

    


    

    
    

    


    

    