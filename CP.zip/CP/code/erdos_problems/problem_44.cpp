#include <bits/stdc++.h>

using namespace std;
int power(long long int a,long long int n,long long int m)
{
  if (m==1) return 1;

    if(n==0)
        return 1;
    else if(n==1)
        return a%m;
    else
    {
        int res=power(a,n/2,m);
        if(n%2==0)
            return ((res)*(res))%m;
    
    else
        return ((res)*(res)*(a))%m;
    }
}



int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    typedef long long int ll;
    ll i,sum=0,temp1,temp2;
   ll c[10]={1,1,4,4,2,1,1,4,4,2};                  // cyclicity store kari 0-9 tk.

   ll store[5][2]={0};
   store[1][0]=power(6,4128,1);
   store[2][0]=power(6,4128,2);
 // store[3][0]=power(6,4128,3);
  store[4][0]=power(6,4128,4);

  store[1][1]=power(4128,6,1);
  store[2][1]=power(4128,6,2);
//  store[3][1]=power(4128,6,3);
  store[4][1]=power(4128,6,4);


    
    for(i=1;i<=17040384;i++)
    {
         temp1=power(i%10,c[i%10]+store[c[i%10]][0],10);          // saara modulo aur cyclicity ka khel h.
         temp2=power(i%10,c[i%10]+store[c[i%10]][1],10);
         sum=sum+(temp1*temp2)%10;
         
    }

    cout<<sum<<endl;
    return 0;
                                                       // 56233268 
     
}
    