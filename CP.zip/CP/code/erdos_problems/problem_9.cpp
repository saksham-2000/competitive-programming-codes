/*

failed attempt to do this via code since factorial wala logic isnt correct.for correct solution and approach,refer to the following link.

https://www.quora.com/What-is-the-smallest-number-with-over-300-divisors


#include <bits/stdc++.h>
using namespace std;



int main() 
{
    typedef long long int ll;
    const ll m =1000000009;
    ll res=1;
    ll n,i,p,x=1,j=0;
    cin>>n;
    bool prime[n+1];
    ll ww=0;
    memset(prime,true,sizeof(prime));
    for(p=2;p*p<=n;p++)
    {
        if(prime[p])
        {
            for(i=p*p;i<=n;i+=p)
            {
                prime[i]=false;
                
            }
        }
    }
    for(i=2;i<=n;i++)
    {
        if(prime[i])
          ww++;
    }
   
    int count[ww+1]={0};


    for(i=2;i<=n;i++)
    {
        if(prime[i])
       { 
        x=1;
        j++;
        while(pow(i,x)<=n)
        {
            count[j]+=n/pow(i,x);
            x++;
        }
       
       }
    }

    for(i=1;i<=ww;i++)
    {
        count[i]++;
        res=(res*count[i])%m;
    }
    

    cout<<(res-1)<<endl;



    return 0;

}
    */