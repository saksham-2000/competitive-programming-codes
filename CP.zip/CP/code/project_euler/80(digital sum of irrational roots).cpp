//FIRST THINK THEN CODE.

#include <bits/stdc++.h>
 
 
using namespace std;
 
typedef long long ll;
 
#define MOD 998244353
#define rep(i,a,b) for(ll i=a;i<b;++i)
#define rrep(i,a,b) for(ll i=a;i>b;--i)
#define vi vector<int>
#define vl vector<ll>
#define ld long double
#define vvi vector<vector<int>>
#define vvl vector<vector<long long>>
#define pii pair<int,int>
#define pll pair<long,long>
#define vpii vector<pii>
#define vpll vector<pll>
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define lb lower_bound
#define ub upper_bound
#define bs binary_search
#define d1(x) cout<<(x)<<endl
#define d2(x,y) cout<<(x)<<" "<<(y)<<endl
#define d3(x,y,z) cout<<(x)<<" "<<(y)<<" "<<(z)<<endl
#define d4(a,b,c,d) cout<<(a)<<" "<<(b)<<" "<<(c)<<" "<<(d)<<endl
#define PI 3.1415926535897932384626433832795
#define fix(f,n) fixed<<setprecision(n)<<f
#define all(x) x.begin(),x.end()
#define endl "\n"

#define IOS ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
 
ll newmod(ll a,ll b)
 {
  return ((a%b)+b)%b;
}
 
 
ll powM(ll a,ll b,ll m )
{ 
  a%=m;
  ll ans=1LL;
  while(b)
  {
    if(b&1)ans=ans*a%m;
    a=a*a%m;
    b>>=1;
  }
 
return ans;
}
 
ll poww(ll a,ll b)
{ 
  
  ll ans=1;
  while(b)
  {
    if(b&1)ans=ans*a;
    a=a*a;
    b>>=1;
  }
 
return ans;

}




//http://www.afjarvis.staff.shef.ac.uk/maths/jarvisspec02.pdf









/*
To illustrate the method, let’s begin to work out the value of the square root
of 2. The initial step sets a = 5 × 2 = 10 and b = 5. So we start with the
pair (a, b) = (10, 5).
Now we perform the repeated steps. As 10 > 5, we must apply R1. We
therefore replace a with a − b, so that now a = 10 − 5 = 5, and add 10 to b,
so that b becomes 15. The new pair is therefore (5, 15).
We apply the rule again. This time, however, a = 5 < 15 = b, and so we
use R2. This rule says: Add two zeroes to the end of a, to make a = 500,
and put a zero before the final digit of b, so that now b = 105. The pair
becomes (500, 105).
Now 500 > 105, so we apply R1, and we replace a by a−b = 500−105 =
395, and add 10 to b, so that b becomes 115. Our pair is then (395, 115).
Repeatedly applying the rules in turn gives:
(10, 5) R1 −→ (5, 15) R2 −→ (500, 105) R1 −→ (395, 115) R1 −→ (280, 125)
R1 −→ (155, 135) R1 −→ (20, 145) R2 −→ (2000, 1405) R1 −→ (595, 1415)
R2 −→ (59500, 14105) R1 −→ (45395, 14115) R1 −→ (31280, 14125)
R1 −→ (17155, 14135) R1 −→ (3020, 14145) R2 −→ (302000, 141405)
R1 −→ (160595, 141415) R1 −→ (19180, 141425) R2 −→ (1918000, 1414205) −→ · · ·
and you can see that the digits of b are settling down to start with 14142 . . ..
Moreover,
√
2 = 1.41421356 . 

*/


bool f(vl& a,vl& b){
  ll s=max(a.size(),b.size());

  a.resize(s,0);
  b.resize(s,0);

  for(int i=s-1;i>=0;i--){
    if(a[i]>b[i])return true;
    else if(a[i]<b[i])return false;
  }
  return true;//a=b.
}

void sub(vl&a,vl &b){
  ll burden=0;
  for(int i=0;i<a.size();i++){
      a[i]=a[i]-b[i]-burden;
      if(a[i]<0){
        burden=1;
        a[i]+=10;
      }
      else{
        burden=0;
      }
  }
}

void ad(vl& b,ll x){
  ll carry=x;
  for(int i=0;i<b.size();i++){
carry+=b[i];
b[i]=carry%10;
carry/=10;
  }
  while(carry){
    b.pb(carry%10);
    carry/=10;
  }
}


void mul(vl& a,ll x){
  ll carry=0;
  for(int i=0;i<a.size();i++){
    carry+=x*a[i];
    a[i]=carry%10;
    carry/=10;
  }
  while(carry){
    a.pb(carry%10);
    carry/=10;
  }
}

int main()
{ 

  IOS;


ll tot=0;

for(int d=1;d<=100;d++){

ld ch=sqrt(d);
if(floor(ch)==ch)continue;
vl a={5};

vl b={5};

mul(a,d);


// storing digits from least significant to most significant.

while(1)
{
//cnt++;
if(f(a,b)){
// returns true if a>=b.
//cout<<"hi"<<endl;
//a-->a-b.
  sub(a,b);
ad(b,10);
  //b-->b+10;

}
else{

a.insert(a.begin(),0);
a.insert(a.begin(),0);
b.insert(b.begin()+1,0);
}

if(b.size()>150&&b[150])break;

}

ll cnt=0;
ll temp=0;
for(int i=b.size()-1;i>=0;i--){
  if(cnt==100)break;
  else if(cnt){
cnt++;
temp+=b[i];
  }
  else{
    if(b[i]){
      cnt=1;
      temp+=b[i];
      continue;
    }
  }
}
//cout<<temp<<endl;
tot+=temp;
}

cout<<tot<<endl;



return 0;
 
}

