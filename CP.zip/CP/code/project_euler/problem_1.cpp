#include <bits/stdc++.h>
using namespace std;



int main() 
{
	typedef long long int ll;
    ll n,result=0,i,p1,p2;
    cin>>n;
    bool multiple[n+1];
    memset(multiple,false,sizeof(multiple));
    
    cin>>p1>>p2;
    for(i=p1;i<n;i+=p1)
    {

    	multiple[i]=true;
    	result+=i;
    }

    for(i=p2;i<n;i+=p2)
    { 
    	if(multiple[i]==false)
       {
    	multiple[i]=true;
    	result+=i;

       }
    }

    cout<<result<<"\n";


    return 0;


}
