#include <bits/stdc++.h>
using namespace std;



int main() 
{
    typedef long long int ll;
    const ll m =1000000009;
    ll res=0;
    ll n,i,p,x=1,j=0;
    cin>>n;
    bool prime[n+1];
    ll ww=0;
    memset(prime,true,sizeof(prime));
    for(p=2;p*p<=n;p++)
    {
        if(prime[p])
        {
            for(i=p*p;i<=n;i+=p)
            {
                prime[i]=false;
                
            }
        }
    }
    for(i=2;i<=n;i++)
    {
        if(prime[i])
          res+=i;
    }
   
   cout<<res<<endl;


    return 0;

}
    




    