#include <bits/stdc++.h>
using namespace std;



int main() 
{
    typedef long long ll;
    ll result1=0,i,j,temp=0;
    int arr[20][20];
    for(i=0;i<20;i++)
    {
        for(j=0;j<20;j++)
        {
            cin>>arr[i][j];
        }
    }

    for(i=0;i<20;i++)
    {
        for(j=0;j<=16;j++)
        {
            temp=arr[i][j]*arr[i][j+1]*arr[i][j+2]*arr[i][j+3];
            result1=max(result1,temp);
        }
    }

    for(i=0;i<=16;i++)
    {
        for(j=0;j<20;j++)
        {
            temp=arr[i][j]*arr[i+1][j]*arr[i+2][j]*arr[i+3][j];
            result1=max(result1,temp);
        }
    }

    for(i=0;i<=16;i++)
    {
        for(j=0;j<=16;j++)
        {
            temp=arr[i][j]*arr[i+1][j+1]*arr[i+2][j+2]*arr[i+3][j+3];
            result1=max(result1,temp);
        }
    }

     for(i=19;i>=3;i--)
     {
        for(j=19;j>=3;j--)
        {
            temp=arr[i][j]*arr[i-1][j-1]*arr[i-2][j-2]*arr[i-3][j-3];
            result1=max(result1,temp);
        }
     }

     for(i=0;i<=16;i++)
     {
        for(j=19;j>=3;j--)
        {
            temp=arr[i][j]*arr[i+1][j-1]*arr[i+2][j-2]*arr[i+3][j-3];
            result1=max(result1,temp);
        }
     }

     for(i=19;i>=3;i--)
     {
        for(j=0;j<=16;j++)
        {
            temp=arr[i][j]*arr[i-1][j+1]*arr[i-2][j+2]*arr[i-3][j+3];
            result1=max(result1,temp);
        }
     }

     cout<<result1<<endl;





    return 0;

}
    




    