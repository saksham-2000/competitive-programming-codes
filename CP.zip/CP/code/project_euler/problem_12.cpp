#include <bits/stdc++.h>

using namespace std;

#define max(a,b) a>=b?a:b

int no_of_divisiors(long long int a)
{
  int i,count=2;
  for( i=2;i*i<a;i++)
  {
    if(a%i==0)count+=2 ;

  }
  if(i*i==a)count++;
  return count;
}

int main()
{
 typedef long long int  ll;
 ll i,temp,maxDiv=0;

for(i=1;i<20000;i++)
 {
  temp=(i)*(i+1)/2;
   maxDiv = max(no_of_divisiors(temp),maxDiv);
   if(maxDiv>500) 
   {
    cout<<temp<<endl;
    break;
   }
 } 
 cout<<maxDiv<<endl;
  return 0;
}
     


    