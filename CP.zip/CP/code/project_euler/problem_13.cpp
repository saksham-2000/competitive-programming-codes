#include <bits/stdc++.h>

using namespace std;




int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    typedef long long int ll;
    ll i,j,carry=0,d=1,temp=0;
   string s[100];
  
   for(i=0;i<100;i++)
   {
    cin>>s[i];
   }
   ll digit[54]={0};


 for(j=49;j>=0;j--)
 {
  for(i=0;i<100;i++)
  {
     temp+=(s[i][j]-48);
  }
  temp+=carry;
  digit[d]=temp%10;
  carry=temp/10;
  temp=0;
  d++;
 }

 while(carry>0)
 {
  digit[d]=carry%10;
  carry/=10;
  d++;
 }
 cout<<--d<<endl;

 for(i=53;i>=1;i--)
 {
  cout<<digit[i];
 }

    return 0;

}
    