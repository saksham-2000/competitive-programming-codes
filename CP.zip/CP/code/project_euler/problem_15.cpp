#include <bits/stdc++.h>

using namespace std;
long long int path(int i,int j,int n)
{
  if(i==n||j==n)
    return 1;

  else return path(i+1,j,n)+path(i,j+1,n);
}

int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    typedef long long int ll;
    ll count,i,n,ans=0;
    float f=0;
    ans= path(0,0,18);
    cout<<ans<<endl;
     

   

    
    
   
    return 0;

}
  //  9075135300