#include <bits/stdc++.h>

using namespace std;



 // this question is inspired by #16 of project euler . This code gives us sum of digits of 3^1000 . answer is 2133 which is 0mod9.

int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    typedef long long int ll;
    
    ll i,j,carry=0,count=0;
    int digit[500]={0};
    digit[1]=1;


    for(i=1;i<=1000;i++)
    {
       for(j=1;j<i*(0.4771)+1;j++)  // log(3) base 10 is 0.4771 .
       {  

          digit[j]=digit[j]*3+carry;
          carry=0;
          if(digit[j]>=10)
          {
            carry=digit[j]/10;;
            digit[j]%=10;
          }

        }


    }
 
 cout<<j<<endl;

      for(i=j-1;i>0;i--)
      {
        count+=digit[i];
      }

      cout<<count<<endl;




    


    return 0;

}
    