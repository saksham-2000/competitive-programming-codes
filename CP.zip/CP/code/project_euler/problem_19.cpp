#include <bits/stdc++.h>

using namespace std;

#define maxi(a,b) (a>=b?a:b)

int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    typedef long long int ll;

    ll n,i,j,k,day=2,count=0;                // har month ka nikal diya ese .
                                              // january and feb ki condition alag hogi baaki months se(think :)  )

    for(i=1901;i<=2000;i++)
    {
      
       if(day==0) count++;

        if((i+1)%4!=0) day++;
       else day+=2;
       day%=7;
    }
    cout<<count<<endl;

    return 0;

}
    