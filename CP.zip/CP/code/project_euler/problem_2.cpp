#include <bits/stdc++.h>
using namespace std;


int main() {
    typedef long long int ll;
    ll result=0,i;
    ll fibonacci[40];
    fibonacci[0]=0,fibonacci[1]=1;
    for( i=2;i<40;i++)
    {
        fibonacci[i]=fibonacci[i-1]+fibonacci[i-2];
    }

    for(i=0;i<40;i++)
    {
    	if(fibonacci[i]<4000000&&fibonacci[i]%2==0)
		{
			result+=fibonacci[i];
		}
    }

    cout<<result<<"\n";


    return 0;


}