#include <bits/stdc++.h>

using namespace std;

#define maxi(a,b) (a>=b?a:b)

int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    typedef long long int ll;

    ll n,i,j,carry=0,temp,count=0;              

    int digit[201]={0};
    digit[1]=1;
    for(i=1;i<=10;i++)
    {
          carry=0;
      for(j=1;j<=200;j++)
      { 
        
        temp=digit[j]*i+carry;
       
          digit[j]=temp%10;
          temp/=10;
          carry=temp;
                 
      }

    }

    for(j=10;j>0;j--)
    {
      count+=digit[j];
    }

    cout<<count<<endl;

  

    return 0;

}
    