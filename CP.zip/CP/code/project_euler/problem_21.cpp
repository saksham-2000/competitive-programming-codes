#include <bits/stdc++.h>

using namespace std;
int sopd(int n)          // sopd= Sum Of Proper Divisors(smaller than that number)
{
  int sum=1,i;
  for(i=2;i*i<n;i++)
  {
      if(n%i==0)
      {
        sum+=n/i+i;
      }
  }             // for loop ke baad ab i ki condition laga rhe. 
  if(i*i==n) sum+=n/i;
  return sum;
}



int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    typedef long long int ll;
    ll i,j,carry=0,d=1;
    int total_sum=0;
    int array[10001]={0};
   
     for(i=2;i<=10000;i++)
     {
      

      if(sopd(i)!=i&&sopd(sopd(i))==i)      // condition for a number to be amicable.
      {

          total_sum+=i;
      }
     

     }

     cout<<total_sum<<endl;
        
    return 0;

}
    