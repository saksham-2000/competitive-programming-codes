#include <bits/stdc++.h>

using namespace std;
long long int sopd(long long int n)          // sopd= Sum Of Proper Divisors(smaller than that number)
{
  long long int sum=1,i;
  for(i=2;i*i<n;i++)
  {
      if(n%i==0)
      {
        sum+=n/i+i;
      }
  }             // for loop ke baad ab i ki condition laga rhe. 
  if(i*i==n) sum+=n/i;

  return sum;
}



int main() 
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    typedef long long int ll;
    ll i,j=1,k,sum=0;
    ll array[7000]={0};
    ll check[60000]={0};
   
     for(i=1;i<=28123;i++)
     {
      
       if(sopd(i)>i)
       {
         array[j]=i;
         j++;
       }
     
     }
  cout<<array[j-1]<<endl;
     for(i=1;i<j;i++)
     {
      for(k=1;k<j;k++)
      {
          check[array[k]+array[i]]++;
          
      }
     }

     for(i=1;i<=28123;i++)
     {
      if(check[i]==0)
      {
        sum+=i;
      }
     }   
      
       
     cout<<sum<<endl;


    return 0;
     

}
    