#include <bits/stdc++.h>

using namespace std;

int main()
{

  int i,j,temp,carry=0,dig=0;
  int array1[1101]={0},array2[1101]={0};
  array1[1]=1,array2[1]=1;

  for(i=3;i<=5000;i++)
  {
    if(i%2==1)
    { 
      for(j=1;j<=1000;j++)
      {
    /*    if(array1[j]==0&&array2[j]==0&& carry==0)
          {
            break;
          }   */
      temp=array1[j]+array2[j]+carry;
      
        array1[j]=temp%10;
        carry=temp/10;
      }
     if(array1[1000]!=0)
     {
      cout<<i<<endl;
      break;
     }
    }
    else 
    {
      for(j=1;j<=1000;j++)
      {
     /*   if(array1[j]==0&&array2[j]==0&& carry==0)
          {
            break;
          }  */
      temp=array1[j]+array2[j]+carry;
      
        array2[j]=temp%10;
        carry=temp/10;
      }
      if(array2[1000]!=0)
     {
      cout<<i<<endl;
      break;
     }
    }

    
  }

  

  for(j=1000;j>=1;j--)
  {
    if(i%2==0)
    {
      cout<<array2[j];
    }
    else
    cout<<array1[j];
  }   
  

  


    return 0;
     

}
    