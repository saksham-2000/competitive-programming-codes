#include <bits/stdc++.h>

using namespace std;

int main()
{

 int i,j,a=1,b,max_recur=0,temp,k;
 int arr[10000]={0};

 for(i=983;i<984;i++)
 { 
  a=1;
  if(i%5!=0&&i%2!=0)
  {
   b=i;
   a*=10;

   for(j=1;j<=2000;j++)
   {
    temp=a/b;
    if(arr[a]!=0)
    {
      max_recur=max(j-arr[a],max_recur);
      if(max_recur==982) cout<<i<<endl;

      break;
    }
     arr[a]=j;
     a=a%b;
     a*=10;
   }
      for(k=0;k<10000;k++) arr[k]=0;

  }

 }

cout<<max_recur<<endl;

    return 0;
     

}
    