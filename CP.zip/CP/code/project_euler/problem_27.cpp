#include <bits/stdc++.h>

using namespace std;

int main()
{
int a,b,n,i,flag=0,temp,consecutive_prime=0,check=0;
 for(a=-999;a<1000;a++)
 {
  for(b=2;b<=1000;b++)
  {
    flag=0;
    check=0;
    for(n=0;n<2000;n++)
    {
      temp=n*n+a*n+b;
      if(temp<0)
      {
        break;
      }
      for(i=2;i*i<=temp;i++)
      {
        if(temp%i==0)
        {
          flag=1;
          break;
        } 
      }
      if(flag==1)
      {
        break;
      }
       check++;

    }
    
    consecutive_prime=max(consecutive_prime,check);  

  /* if(consecutive_prime==71)                       // pehle iss code ko chalaya to pata chala ki largest value 71 hai.
   {                                                 
    cout<<a<<" "<<b<<a*b<<endl;                       // fir uske baad 71 value par a and b ki values dekh li .
                                                          // a=-61 , b=971 
    consecutive_prime=72;
   }  */

      
  }

 }

 cout<<consecutive_prime<<endl;

    return 0;
    }
     


    