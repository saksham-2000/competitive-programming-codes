#include <bits/stdc++.h>

using namespace std;

typedef long long int ll;



int main()
{ 
   ll i,sum=0;
   for(i=1;i<=500;i++)
   {
    sum+=16*i*i+4*i+4;
   }

   cout<<++sum<<endl;;


return 0;

}
     


    

    


    

    

    

    


    

    
    

    


    

    


    

    


    

    
    

    


    

    