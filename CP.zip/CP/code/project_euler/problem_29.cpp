#include <bits/stdc++.h>

using namespace std;

#define loop(i,n) for(i=0;i<n;i++)
typedef long long ll;
ll const m =1000000007;
 


int main()
{
  int i,j,k,count=0;
 int check[101][601]={0};
int arr[101]={0};



for(i=2;i<=100;i++)
{
  k=1;
  if(arr[i]==0)
  {  
  while((int)(pow(i,k)+0.5)<=100)
  {
    arr[(int)(pow(i,k)+0.5)]=1;
    for(j=2;j<=100;j++)
    {
      check[i][j*k]++;
    }
    k++;
  }
  }
}

for(i=2;i<=100;i++)
{

  for(j=2;j<=600;j++)
  {
    if(check[i][j]!=0)count++;
  }
}

cout<<count<<endl;

return 0;
}
     


    

    
