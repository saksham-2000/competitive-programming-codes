#include <bits/stdc++.h>           // see the alternative solution of this ques below. it is better indeed.
using namespace std;



int main() 
{
    typedef long long int ll;
    const ll m =1000000009;
    ll res=1;
    ll n,i,p,x=600851475143;
    n=7000;
    bool prime[n+1];
    ll max_prime=0;
    memset(prime,true,sizeof(prime));
    for(p=2;p*p<=n;p++)
    {
        if(prime[p])
        {
            for(i=p*p;i<=n;i+=p)
            {
                prime[i]=false;
                
            }
        }
    }


   for(p=2;p<=n;p++)
   { 
      if(x==1)break;
    if(prime[p])
    {
        while(x%p==0)
        {
           x=x/p;
           max_prime=p;
        }
        
    }

   }
      cout<<max_prime<<"\n";
      cout<<x<<endl;

    return 0;

} 




/*  #include <bits/stdc++.h>
using namespace std;



int main() 
{
   typedef long long int ab;
   ab n=600851475143,i;
   for(i=2;i<=10000;i++)                          // 6857 .
   { 
   
    if(n%i==0)
    {
      while(n%i==0)
      {
        n=n/i;
      }
    }
     if(n==1) 
    {
         cout<<i<<endl;
         break;
    } 
   }
 


    return 0;

}           */