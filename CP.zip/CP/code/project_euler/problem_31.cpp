#include <bits/stdc++.h>

using namespace std;


typedef long long ll;


int main()
{ 
  // int sum;cin>>sum;
int i,j,count=0;
  int arr[9][201];
  int coins[9]={0,1,2,5,10,20,50,100,200};
  

 /* for(i=0;i<4;i++)
  {
    for(j=0;j<6;j++)
    {
        if(i==0&&j==0)arr[i][j]=0;
        else if(i==0)arr[i][j]=0;
        else if(j==0)arr[i][j]=1;
     else
      arr[i][j]=0;
    }
  }
*/
    


  for(i=0;i<9;i++)
  {
    for(j=0;j<201;j++)
    {
       if(i==0&&j==0)arr[i][j]=1;
        else if(i==0)arr[i][j]=0;
        else if(j==0)arr[i][j]=1;
     else
     {
        arr[i][j]=arr[i-1][j];
        if(j-coins[i]>=0)
        arr[i][j]+=arr[i][j-coins[i]];
      }
    }

  }

  for(i=0;i<9;i++)
  {
    for(j=0;j<201;j++)
    {
      cout<<arr[i][j]<<" ";
    }
    cout<<endl;
  }

//  bas ab last row and last column wala element print karade.

return 0;

}
     


    

    


    

    
    

    


    

    