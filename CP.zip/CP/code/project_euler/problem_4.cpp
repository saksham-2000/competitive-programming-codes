#include <bits/stdc++.h>

using namespace std;
bool isPalindrome(int i)
{
 stringstream ss;
 ss<<i;
 string s;
 ss>>s;
  int j,n=s.length();
  for(j=0;j<n/2;j++)
  {
    if(s[j]!=s[n-1-j])
    {
      return false;
    }
  }
return true;
}

int main()
{
 int i,j,max_value=0;

for(i=100;i<1000;i++)
{
  for(j=100;j<1000;j++)
  {
    if(isPalindrome(i*j))
      max_value=max(max_value,i*j);
  }
}

cout<<max_value<<endl;
    return 0;
}
     


    