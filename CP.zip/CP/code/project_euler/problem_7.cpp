#include <bits/stdc++.h>

using namespace std;



int main() 
{
    typedef long long int ll;
    const ll m =1000000009;
    ll res=1;
    ll n,i,p,x=1,j=0;
    cin>>n;
    bool prime[n+1];
    ll ww=0;
    memset(prime,true,sizeof(prime));
    for(p=2;p*p<=n;p++)
    {
        if(prime[p])
        {
            for(i=p*p;i<=n;i+=p)
            {
                prime[i]=false;
                
            }
        }
    }
    for(i=2;i<=n;i++)
    {
        if(prime[i])
          ww++;
      if(ww==10001)
      {
        cout<<i<<endl;
        
      }
    }

    cout<<ww<<endl;
   
    



    return 0;

}
    