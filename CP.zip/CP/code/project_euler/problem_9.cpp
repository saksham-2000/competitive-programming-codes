#include <bits/stdc++.h>

using namespace std;



int main() 
{
    typedef long long int ll;
    ll i,j,result1=1,result2=0;
    for(i=1;i<1000;i++)
    {
        for(j=i+1;j<=1000;j++)
        {
            if(i*i+j*j==(1000-i-j)*(1000-i-j))
            {
                cout<<i<<" "<<j<<endl;
                cout<<i*j*(1000-i-j);
                break;
            }
        }
    }
    return 0;

}
    