#include <bits/stdc++.h>
#include <tuple>
using namespace std;
#define ll long long
#define FOR(i,a,b)  for(ll i=a;i<=b;i++)
#define FORR(i,a,b)  for(ll i=a;i>=b;i--)
#define repr(i,n) for(ll i=n-1;i>=0;i--)
#define rep(i,n) for(ll i=0;i<n;i++)
#define vl vector<ll>
#define vi vector<int>
#define ld long double
#define vld vector<ld>
#define vvl vector<vector<ll> >
#define vvi vector<vector<int> >
#define vvld vector<vector<ld> >
#define pll pair<ll,ll>
#define vpll vector<pll>
#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define all(x) x.begin(),x.end()
#define rev(p) reverse(p.begin(),p.end());
#define ub(v,val) upper_bound(v.begin(),v.end(),val)
#define np(str) next_permutation(str.begin(),str.end())
#define lb(v,val) lower_bound(v.begin(),v.end(),val)
#define sortv(vec) sort(vec.begin(),vec.end())
#define mset(a,val) memset(a,val,sizeof(a));
#define PI 3.14159265358979323846264338327950288419716939937510
#define yes cout<<"YES"<<"\n"
#define no cout<<"NO"<<"\n"
#define FAST std::ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)

const ll N = 2e6 + 5;
const ll INF = 100000000000;

ll mind(ll x, ll y)
{
  if (x < y) {
    return x;
  }
  else
  {
    return y;
  }
}

ll poww(ll a, ll b) {
  if (b < 0 || a <= 0)return 0;
  ll ans = 1LL;
  while (b) {
    if (b & 1)ans = ans * a;
    a = a * a;
    b >>= 1;
  }
  return ans;
}

ll gcd(ll a, ll b) {
  if (b == 0)
    return a;
  return gcd(b, a % b);
}
ll getSum(ll num)
{
  ll sum = 0;
  while (num != 0) {
    sum = sum + num % 10;
    num = num / 10;
  }
  return sum;
}
//////////////////////////////END OF TEMPLATE//////////////////////////////

int main() {

#ifndef ONLINE_JUDGE

  freopen("input1.txt", "r", stdin);
  freopen("output1.txt", "w", stdout);

#endif


  FAST;

  ll n; cin >> n;
  vl a(n);
  rep(i, n) {
    cin >> a[i];
  }
  vl temp;
  temp.pb(a[0]);
  FOR(i, 1, n - 1) {
    if (a[i] >= temp.back())temp.pb(a[i]);
    else {
      ll id = ub(temp, a[i]) - temp.begin();
      if (i != n - 1)temp[id] = a[i];

    }
  }
  ll ans = temp.size();
  cout << ans;
  cout << endl;
  rep(i, temp.size()) {
    cout << temp[i] << " ";
  }

  return 0;
}
//NOTE: This is for longest non decreasing subsequence.
//I have included the print feature too.







