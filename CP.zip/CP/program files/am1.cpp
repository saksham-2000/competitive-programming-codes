#include<bits/stdc++.h>
//#include<ext/pb_ds/assoc_container.hpp>

//using namespace __gnu_pbds;
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef long double lld;
#define rep(i,n) for(i=0; i<n; i++)
#define repr(i,n) for(i=n; i>0;i--)
#define repa(i,a,n) for(i=a; i<n;i++)
#define repit(x, k) for(auto x:k)
#define vi vector<int>
#define vll vector<ll>
#define vvl vector<vector<long long>>
#define pii pair<int, int>
#define pll pair<ll, ll>
#define mll map<ll, ll>
#define fi first
#define se second
#define pb(t) push_back(t)
#define pf(t) push_front(t)
#define ins(t) insert(t)
#define mp(a,b) make_pair(a, b)
#define mtup(a,b,c) make_tuple(a,b,c)
#define fbo(x) find_by_order(x) //value at position
#define ook(x) order_of_key(x) //position of value
#define lowb(x) lower_bound(x)
#define uppb(x) upper_bound(x)
#define mset(a, val) memset(a, val, sizeof(a))
#define lexcomp(a,b) lexicographical_compare(a, a+n, b, b+n)
#define lex(str1, str2) lexicographical_compare(str1.begin(), str1.end(), str2.begin(), str2.end())
#define present(s,x) (s.find(x) != s.end()) //returns false if absent
#define itos(x) to_string(x)
#define stoi(x) stoll(x)
#define all(v) v.begin(), v.end()
//binary
#define totones(x) __builtin_popcountll(x)
#define tzeros(x) __builtin_ctzll(x)
#define lzeros(x) __builtin_clzll(x)
#define parity(x) __builtin_parityll(x)
#define SPEED   ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)

#define M 1000000007
#define epsilon 1e-9
#define PI  3.14159265
#define INF 1e9+5
#define INFF  1000000000000000005ll

#define pqb priority_queue<int>
#define pqs priority_queue<int, vi, greater<int>>

//functions
ll modpwr(ll a, ll b, ll p) {
  ll res = 1; a = a % p; while (b > 0) {
    if (b & 1) res = (res * a) % p;
    b >>= 1; a = (a * a) % p;
  } return res;
}
ll pwr(ll a, ll b) {
  ll res = 1; while (b > 0) {
    if (b & 1) res *= a;
    b >>= 1; a *= a;
  } return res;
}
ll modinv(ll n, ll p) { return modpwr(n, p - 2, p);}
ll gcd(ll a, ll b) {if (b == 0)return a; return gcd(b, a % b);}
ll lcm(ll a, ll b) {return (a * b) / gcd(a, b);}
ll gcdex(ll a, ll b, ll &x, ll &y) {
  if (a == 0) {x = 0; y = 1; return b;}
  ll x1, y1; ll gcd = gcdex(b % a, a, x1, y1);
  x = y1 - (b / a) * x1; y = x1; return gcd;
}
bool prime(ll x) {
  for (ll i = 2; i * i <= x; i++) {
    if (x % i == 0) return false;
  } return true;
}
ll coprime(ll n) {
  if (n == 0) return 0; if (n == 1) return 1;
  ll res = n;
  for (ll i = 2; i * i <= n; i++) {
    if (n % i == 0) {while (n % i == 0) {n /= i;} res -= res / i;}
  }
  if (n > 1) { res -= (res / n);} return res;
}

//template <typename T>
//typedef tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update> indexed_set;

/*//-- prime vector generation
vll pr;
void SieveOfEratosthenes(ll n){
  bool prime[n+1];
  mset(prime, true);
  for(ll p=2; p*p<=n; p++) if( prime[p] == true) for(ll i=p*p; i<=n; i+=p) prime[i]=false;
  for(ll p=2; p<=n; p++) if(prime[p]) pr.pb(p);
}*/

/*//-- co-prime (less than number) vector generation
vll eulerT;
void SieveOfTotient(ll n){
  vll phi(n+1, 0);phi[0]=0;phi[1]=1;ll i,j;
  rep(i,n+1) phi[i] = i;
  for(ll i=2; i<=n;i++){
    if(phi[i] == i) for(ll j=i; j<=n;j+=i) phi[j] -= phi[j]/i;}
  rep(i, n+1) eulerT.pb(phi[i]);}
*/

// CLOCK
// ll begtime = clock();
// #define time() cout << "\n\nTime elapsed: " << (clock() - begtime)*1000/CLOCKS_PER_SEC << " ms\n\n";
// mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
// CLOCK ENDED

int m, n;
vector< vector<int>> vect;
bool func(ll mid) {
  ll sum = 0, i;
  rep(i, n) {
    int time, z, y;
    time = vect[i][0];
    z = vect[i][1];
    y = vect[i][2];
    sum += (z * (mid / (y + z * time))) + ((mid % (y + z * time)) / time);
    if (sum >= m) return 1;
  }
  if (sum >= m) return 1;
  else return 0;

}


int main() {
  SPEED;
#ifndef ONLINE_JUDGE
  freopen("input.txt", "r", stdin);
  freopen("output.txt", "w", stdout);
#endif
  ull i, j;
  int t = 1;
  // cin >> t;
  while (t--) {

    cin >> m >> n;
    vect.resize(n);
    rep(i, n) {
      vect[i].resize(3);
      // cin>> vect[i][0]>>vect[i][1]>>vect[i][2];
      scanf("%d %d %d", &vect[i][0], &vect[i][1], &vect[i][2]);
    }

    ll l = 0; //certified bad time
    ll r = 15001; //certified good time
    while (r > l + 1) {

      ll mid = l + (r - l) / 2;
      if (func(mid)) r = m;
      else l = m;
    }

    cout << r << endl;

    rep(i, n) {
      int time, z, y;
      time = vect[i][0];
      z = vect[i][1];
      y = vect[i][2];
      cout << (z * (r / (y + z * time))) + ((r % (y + z * time)) / time) << " ";
    } cout << endl;




  }
}
