#include <bits/stdc++.h>

using namespace std;

#define ll long long

int main() {

#ifndef ONLINE_JUDGE

	freopen("input1.txt", "r", stdin);
	freopen("output1.txt", "w", stdout);

#endif

	int t;

	cin >> t;

	ll mod = 1e9 + 7;

	while (t--) {

		ll n;

		cin >> n;

		if (n == 0) {
			cout << 1 << endl;
			continue;
		}

		cout << 4 * n << endl;
	}


	return 0;

}