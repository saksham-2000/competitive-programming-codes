// FIRST THINK THEN CODE.

#include<iostream>
#include <bits/stdc++.h>

using namespace std;

#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;

#define ll long long
#define ld long double
#define pll pair<ll,ll>
#define cld complex<ld>
#define vl vector<ll>
#define vvl vector<vector<ll>>
#define vld vector<ld>
#define vvld vector<vector<ld>>
#define vpll vector<pll>
#define vcld vector<cld>
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define lb lower_bound
#define ub upper_bound
#define eb emplace_back
#define PI acos(-1)
#define endl "\n"
#define fix(f,n) fixed<<setprecision(n)<<f
#define all(x) x.begin(),x.end()
#define rev(p) reverse(p.begin(),p.end());
#define mset(a,val) memset(a,val,sizeof(a));
#define IOS ios_base::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
#define popcount(x) __builtin_popcountll(x)
#define sz(x) ((ll)x.size())
#define FOR(i,a,b)  for(ll i=a;i<=b;i++)
#define FORR(i,a,b)  for(ll i=a;i>=b;i--)
const ll M = 1000000007;
const ll MM = 998244353;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

#define ordered_set tree<pll, null_type,less<>, rb_tree_tag,tree_order_statistics_node_update>

ll begtime = clock();
#define end_routine() cerr << "\n\nTime elapsed: " << (clock() - begtime)*1000/CLOCKS_PER_SEC << " ms\n\n";

template<typename T, typename F>
void chmax( T &a, F b) {
	if (b > a)a = b;
}

template<typename T, typename F>
void chmin( T &a, F b) {
	if (b < a)a = b;
}

const ll N = 2e5 + 5;




void OJ() {


#ifndef ONLINE_JUDGE

	freopen("input1.txt", "r", stdin);
	freopen("output1.txt", "w", stdout);

#endif

}

int main() {

	IOS;

	OJ();


	/*

	You have a knapsack of Capacity S.

	there are n items with weight wi and cost ci.

	choose some subset of the


	*/

	ll n, S;

	cin >> n >> S;

	vl w(n), c(n);

	for (ll i = 0; i < n; i++) {
		cin >> w[i] >> c[i];
	}

	ll ans = 0;

	for (ll msk = 0; msk < (1ll << n); msk++) {
		ll ret = 0;
		ll tw = 0;
		for (ll j = 0; j < n; j++) {
			if ((1ll << j)&msk) {
				ret += c[j];
				tw += w[j];
			}
		}
		if (tw <= S) {
			ans = max(ans, ret);
		}
	}
	cout << ans << endl;




	return 0;


}

