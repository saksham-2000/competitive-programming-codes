#include <bits/stdc++.h>

typedef long long int ll;
typedef long double ld;
using namespace std;
#define P 1000000007
#define rep(i,n) for(i=0;i<n;++i)
#define re(i,a,n) for(i=a;i<=n;++i)
#define repr(i,a,n) for(i=a;i>=n;--i)
#define pb push_back
#define mp make_pair
#define fi first
#define se second
#define ub(v,val) upper_bound(v.begin(),v.end(),val)
#define np(str) next_permutation(str.begin(),str.end())
#define lb(v,val) lower_bound(v.begin(),v.end(),val)
#define sortv(vec) sort(vec.begin(),vec.end())
#define rev(p) reverse(p.begin(),p.end());
#define mset(a,val) memset(a,val,sizeof(a));
#define at(s,pos) *(s.find_by_order(pos))
#define set_ind(s,val) s.order_of_key(val)
#define block_size ((ll)sqrt(3e5) + 1)
/*#include <ext/pb_ds/assoc_container.hpp> // Common file
#include <ext/pb_ds/tree_policy.hpp>
#include <functional> // for less
#include <iostream>
// Important header files
using namespace __gnu_pbds;
using namespace std;
template <typename T>
using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;*/

ll binpowmod(ll a, ll b, ll m) {
  a %= m;
  ll res = 1;
  while (b > 0) {
    if (b & 1)
      res = res * a % m;
    a = a * a % m;
    b >>= 1;
  }
  return res;
}
const int maxn = 2e5 + 1;
vector<vector<ll>> adj;
vector<ll> near, dis, spec, near1;

ll clos;
vector<ll> tr;

void dfs(ll u, ll dep, ll p, ll sp)
{
  dis[u] = dep;
  near[u] = sp;
  tr[u] = sp;
  if (spec[u] == 1)
  {
    near[u] = u;
    tr[u] = u;
    near1[u] = u;
    sp = u;
  }
  for (auto v : adj[u])
  {
    if (v != p)
    {
      dfs(v, dep + 1, u, sp);
      if (near1[v] != -1)
      {
        near1[u] = near1[v];
      }
    }
  }

}


void dfs1(ll u, ll p, ll sp, ll d)
{
  if (near1[u] == -1)
  {
    near[u] = sp;
    tr[u] = d;
  }
  else
  {
    sp = u;
    d = near1[u];
  }
  for (auto v : adj[u])
  {
    if (v != p)
      dfs1(v, u, sp, d);
  }
}



int main()
{
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  ll i, j, l, r, f, e, x, y, mid, z, w, k, h, n, m, a, b, c;
  ll t1, t2, t3, ans = 0, tc, t ;
  cin >> t ;
  while (t--)
  {
    adj.clear();
    near.clear();
    spec.clear();
    dis.clear();
    near1.clear();
    cin >> n >> k >> a ;
    adj.resize(n + 1);
    near.resize(n + 1);
    dis.resize(n + 1);
    spec.resize(n + 1);
    spec.assign(n + 1, 0);
    near1.resize(n + 1);
    near1.assign(n + 1, -1);
    near.assign(n + 1, 0);
    vector<ll> spnodes(k);
    rep(i, k)
    {
      cin >> spnodes[i] ;
      spec[spnodes[i]] = 1;
    }
    rep(i, n - 1)
    {
      cin >> x >> y ;
      adj[x].pb(y);
      adj[y].pb(x);
    }
    tr.clear();
    tr.resize(n + 1);
    tr.assign(n + 1, -1);
    dfs(a, 0, 0, -1);
    dfs1(a, 0, -1, -1);

    //cout << h1.fi << " " << h1.se << "\n";

    vector<pair<ll, ll>> res(n + 1);
    re(i, 1, n)
    {
      //cout << near[i] << endl ;
      if (near1[i] != -1)
      {
        res[i].fi = dis[i];
        res[i].se = near1[i];
      }
      else
      {
        if (near[i] == -1)
        {
          res[i].fi = -dis[i];
          res[i].se = spnodes[0];
        }
        else
        {
          res[i].fi = 2 * dis[near[i]] - dis[i];
          res[i].se = tr[i];
        }
      }
    }
    re(i, 1, n) cout << res[i].fi << " ";
    cout << "\n" ;
    re(i, 1, n) cout << res[i].se << " " ;
    cout << "\n" ;



  }
  return 0;

}