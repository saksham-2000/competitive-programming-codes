#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define FOR(i,a,b)  for(ll i=a;i<=b;i++)
#define FORR(i,a,b)  for(ll i=a;i>=b;i--)
#define repr(i,n) for(ll i=n-1;i>=0;i--)
#define rep(i,n) for(ll i=0;i<n;i++)
#define vl vector<ll>
#define ld long double
#define vld vector<ld>
#define vvl vector<vector<ll> >
#define vvld vector<vector<ld> >
#define pll pair<ll,ll>
#define vpll vector<pll>
#define fi first
#define se second
#define pb push_back
#define mp make_pair
#define all(x) x.begin(),x.end()
#define rev(p) reverse(p.begin(),p.end());
#define ub(v,val) upper_bound(v.begin(),v.end(),val)
#define np(str) next_permutation(str.begin(),str.end())
#define lb(v,val) lower_bound(v.begin(),v.end(),val)
#define sortv(vec) sort(vec.begin(),vec.end())
#define mset(a,val) memset(a,val,sizeof(a));
#define PI 3.14159265358979323846264338327950288419716939937510
#define yes cout<<"YES"<<"\n"
#define no cout<<"NO"<<"\n"
#define FAST std::ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)

const ll N = 2e6 + 5;
const ll INF = 1000000000;

ll maxd(ll x, ll y)
{
  if (x > y) {
    return x;
  }
  else
  {
    return y;
  }
}

ll poww(ll a, ll b) {
  if (b < 0 || a <= 0)return 0;
  ll ans = 1LL;
  while (b) {
    if (b & 1)ans = ans * a;
    a = a * a;
    b >>= 1;
  }
  return ans;
}

ll gcd(ll a, ll b) {
  if (b == 0)
    return a;
  return gcd(b, a % b);
}
//////////////////////////////END OF TEMPLATE//////////////////////////////

int main() {

#ifndef ONLINE_JUDGE
  freopen("input1.txt", "r", stdin);
  freopen("output1.txt", "w", stdout);
#endif
  FAST;

  tuple<int, int, int> t;
  t = make_tuple(1, 2, 3);


  cout << get<1>(t);

  return 0;
}












