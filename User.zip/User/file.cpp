#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;


int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
 int k,i,count=0,temp,x;
 vector<ll>v;
 cin>>k;
 for(i=1;i<=9;i++)v.push_back(i);  

while(count!=k)
{
  x=v[0];
  v.erase(v.begin());
  count++;
  if(x%10!=0)v.push_back(10*x+x%10-1);
  v.push_back(10*x+x%10);
  if(x%10!=9)v.push_back(10*x+x%10+1);
}

cout<<x<<endl;


return 0;
}
